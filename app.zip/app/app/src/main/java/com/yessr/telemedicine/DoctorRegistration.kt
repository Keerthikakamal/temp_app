package com.yessr.telemedicine

import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import com.yessr.telemedicine.databinding.ActivityDoctorRegistrationBinding
import org.w3c.dom.Document
import java.util.*

class DoctorRegistration : AppCompatActivity() {

    private lateinit var binding: ActivityDoctorRegistrationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDoctorRegistrationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.etFromTime.setOnClickListener {
            showTimePickerDialog(binding.etFromTime)
        }

        binding.etToTime.setOnClickListener {
            showTimePickerDialog(binding.etToTime)
        }

        binding.txtLogin.setOnClickListener {
            val intent = Intent(this, DoctorLogin::class.java)
            startActivity(intent)
        }

        binding.btnDoctorSubmit.setOnClickListener {

            val name = binding.etDoctorName.text.trim().toString()
            val profession = binding.etDoctorProfession.text.trim().toString()
            val location = binding.etDoctorLocation.text.trim().toString()
            val phoneNumber = binding.etDoctorPhoneNumber.text.trim().toString()
            val password = binding.etDoctorPassword.text.trim().toString()
            val fromTime = binding.etFromTime.text.trim().toString()
            val toTime = binding.etToTime.text.trim().toString()


            if (fromTime.isEmpty() || toTime.isEmpty()) {
                Toast.makeText(this, "Please select availability time.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }


            val intent = Intent(this, DoctorHome::class.java)


            intent.putExtra("NAME", name)
            intent.putExtra("PROFESSION", profession)
            intent.putExtra("LOCATION", location)
            intent.putExtra("PHONE_NUMBER", phoneNumber)
            intent.putExtra("PASSWORD", password)
            intent.putExtra("FROM_TIME", fromTime)
            intent.putExtra("TO_TIME", toTime)


            startActivity(intent)
        }
    }


    private fun showTimePickerDialog(editText: EditText) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(this, { _, selectedHour, selectedMinute ->
            val time = String.format("%02d:%02d", selectedHour, selectedMinute)
            editText.setText(time)
        }, hour, minute, true)

        timePickerDialog.show()
    }
}