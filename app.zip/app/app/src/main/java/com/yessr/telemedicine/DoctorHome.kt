package com.yessr.telemedicine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DoctorHome : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_home)
    }
}